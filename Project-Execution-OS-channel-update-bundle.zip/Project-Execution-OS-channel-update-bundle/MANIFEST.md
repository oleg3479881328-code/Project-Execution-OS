# MANIFEST

## Package

`Project-Execution-OS-channel-update-bundle.zip`

## Purpose

Install the revised single-entry communication-channel routing model into `Project-Execution-OS`.

## Overlay Files

- `overlay/docs/ROUTER.md`
- `overlay/blocks/communication-channel/BLOCK.md`
- `overlay/docs/AI_COORDINATION_HUB_STANDARD.md`
- `overlay/docs/integrations/chatgpt/CODEX_GITHUB_PROTOCOL.md`

## Agent Instructions

- `AGENT_START_HERE.md`

## Safe Apply Script

- `scripts/apply_channel_update.py`

## Expected Architectural Result

One top-level route only:

```text
Канал связи
→ blocks/communication-channel/BLOCK.md
```

Nested routes only:

```text
blocks/communication-channel/BLOCK.md
→ docs/AI_COORDINATION_HUB_STANDARD.md
→ docs/integrations/chatgpt/CODEX_GITHUB_PROTOCOL.md   # only when GitHub is selected
```

## Files Explicitly Not Modified

- `START_HERE.md`
- all files outside the four overlay paths
