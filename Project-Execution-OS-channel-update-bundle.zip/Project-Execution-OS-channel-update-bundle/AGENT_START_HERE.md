# AGENT START HERE — APPLY COMMUNICATION CHANNEL REFACTOR

## Задача

Внести в репозиторий `Project-Execution-OS` минимальное изменение архитектуры канала связи.

Новая модель должна иметь только одну верхнеуровневую ветку:

```text
START_HERE.md
→ docs/ROUTER.md
→ Канал связи
→ blocks/communication-channel/BLOCK.md
→ docs/AI_COORDINATION_HUB_STANDARD.md
→ выбранный конкретный канал
```

GitHub-протокол совместной работы `ChatGPT <-> Codex` должен остаться вложенным частным маршрутом:

```text
blocks/communication-channel/BLOCK.md
→ docs/AI_COORDINATION_HUB_STANDARD.md
→ GitHub выбран как канал связи
→ docs/integrations/chatgpt/CODEX_GITHUB_PROTOCOL.md
```

## Важное ограничение

`START_HERE.md` не менять.

Он обязан оставаться минимальной стабильной точкой входа.

## Что находится в этом ZIP

- `overlay/` — готовые целевые версии четырёх файлов по правильным путям.
- `scripts/apply_channel_update.py` — безопасный скрипт проверки и применения.
- `MANIFEST.md` — список файлов и ожидаемый результат.
- `AGENT_START_HERE.md` — эта инструкция.

## Допустимые изменения

Менять разрешено только:

- `docs/ROUTER.md`
- `blocks/communication-channel/BLOCK.md`
- `docs/AI_COORDINATION_HUB_STANDARD.md`
- `docs/integrations/chatgpt/CODEX_GITHUB_PROTOCOL.md`

Запрещено менять любые другие файлы.

## Порядок выполнения

1. Убедиться, что ZIP лежит в корне репозитория `Project-Execution-OS`.
2. Распаковать ZIP в отдельную временную папку рядом с ZIP-файлом.
3. Открыть терминал в корне репозитория.
4. Проверить чистоту рабочего дерева:

```bash
git status --short
```

5. Если есть несвязанные локальные изменения — остановиться и сообщить владельцу. Не перетирать их.
6. Проверить пакет без записи:

```bash
python <папка_распакованного_пакета>/scripts/apply_channel_update.py --repo-root . --check
```

7. Прочитать текущие версии четырёх разрешённых файлов и сравнить их с `overlay/`.
8. Применить пакет:

```bash
python <папка_распакованного_пакета>/scripts/apply_channel_update.py --repo-root . --apply
```

9. Выполнить проверку:

```bash
git diff -- START_HERE.md
git diff -- docs/ROUTER.md blocks/communication-channel/BLOCK.md docs/AI_COORDINATION_HUB_STANDARD.md docs/integrations/chatgpt/CODEX_GITHUB_PROTOCOL.md
git status --short
```

10. Убедиться, что:

- `START_HERE.md` не изменён;
- в `docs/ROUTER.md` существует ровно один верхнеуровневый маршрут для связи;
- этот маршрут ведёт в `blocks/communication-channel/BLOCK.md`;
- прямые верхнеуровневые маршруты в `docs/AI_COORDINATION_HUB_STANDARD.md` и `docs/integrations/chatgpt/CODEX_GITHUB_PROTOCOL.md` удалены;
- внутри `blocks/communication-channel/BLOCK.md` присутствуют оба вложенных маршрута;
- название блока — `Канал связи`;
- команды `01` и `02` описаны как команды связи, а не разрешение на выполнение;
- payload (содержимое задания) и transport (канал передачи) разделены.

11. Сделать один commit:

```bash
git add docs/ROUTER.md blocks/communication-channel/BLOCK.md docs/AI_COORDINATION_HUB_STANDARD.md docs/integrations/chatgpt/CODEX_GITHUB_PROTOCOL.md
git commit -m "Refactor communication routing into single channel block"
```

12. Выполнить push в текущую рабочую ветку:

```bash
git push
```

13. Вернуть владельцу отчёт.

## Формат обязательного отчёта

```text
EXECUTION REPORT

STATUS:
FILES CHANGED:
START_HERE.md UNCHANGED: yes / no
TOP-LEVEL COMMUNICATION ROUTES IN docs/ROUTER.md:
VALIDATION PERFORMED:
VALIDATION NOT PERFORMED:
BLOCKERS:
ASSUMPTIONS:
COMMIT SHA:
PUSH CONFIRMED: yes / no
READY FOR REVIEW: yes / no
```

## Стоп-условия

Немедленно остановиться без записи, если:

- репозиторий не тот;
- `START_HERE.md` изменён локально;
- есть несвязанные локальные изменения;
- один из разрешённых файлов имеет конфликтующую новую архитектуру, которую пакет может затереть;
- скрипт сообщает ошибку;
- после применения изменились файлы вне разрешённого списка.

## Итоговое правило

Не заявлять, что работа завершена, пока отсутствуют:

- фактический diff;
- commit SHA;
- подтверждённый push;
- результаты проверки.
