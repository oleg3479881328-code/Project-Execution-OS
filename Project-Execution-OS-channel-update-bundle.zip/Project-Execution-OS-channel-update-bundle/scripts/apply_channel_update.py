#!/usr/bin/env python3
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

ALLOWED = [
    Path("docs/ROUTER.md"),
    Path("blocks/communication-channel/BLOCK.md"),
    Path("docs/AI_COORDINATION_HUB_STANDARD.md"),
    Path("docs/integrations/chatgpt/CODEX_GITHUB_PROTOCOL.md"),
]

def run_git(repo_root: Path, *args: str) -> str:
    result = subprocess.run(
        ["git", *args],
        cwd=repo_root,
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"git {' '.join(args)} failed\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}"
        )
    return result.stdout

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check", action="store_true")
    mode.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    package_root = Path(__file__).resolve().parent.parent
    overlay_root = package_root / "overlay"
    repo_root = Path(args.repo_root).resolve()

    if not (repo_root / ".git").exists():
        print("ERROR: repo root does not contain .git")
        return 2

    if not (repo_root / "START_HERE.md").exists():
        print("ERROR: START_HERE.md not found. Wrong repository?")
        return 2

    status = run_git(repo_root, "status", "--short")
    if status.strip():
        print("ERROR: working tree is not clean. Stop before applying.")
        print(status)
        return 3

    print("Repository:", repo_root)
    print("Mode:", "APPLY" if args.apply else "CHECK")
    print("Allowed files:")
    for rel in ALLOWED:
        src = overlay_root / rel
        dst = repo_root / rel
        print(f"- {rel}")
        if not src.exists():
            print(f"  ERROR: missing overlay file: {src}")
            return 4
        if not dst.exists():
            print(f"  ERROR: target file does not exist: {dst}")
            return 4

    if args.check:
        print("\nCHECK PASSED: package is ready to apply.")
        print("No repository files were changed.")
        return 0

    backup_root = package_root / "backup-before-apply"
    if backup_root.exists():
        shutil.rmtree(backup_root)

    for rel in ALLOWED:
        src = overlay_root / rel
        dst = repo_root / rel
        backup = backup_root / rel
        backup.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(dst, backup)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

    changed = run_git(repo_root, "status", "--short")
    print("\nRepository changes:")
    print(changed)

    changed_paths = []
    for line in changed.splitlines():
        if not line.strip():
            continue
        changed_paths.append(Path(line[3:].strip()))

    unexpected = [p for p in changed_paths if p not in ALLOWED]
    if unexpected:
        print("\nERROR: unexpected changed paths detected:")
        for p in unexpected:
            print("-", p)
        print("Restore from backup-before-apply before continuing.")
        return 5

    start_here_diff = run_git(repo_root, "diff", "--", "START_HERE.md")
    if start_here_diff.strip():
        print("\nERROR: START_HERE.md changed unexpectedly.")
        return 6

    print("\nAPPLY PASSED.")
    print("START_HERE.md unchanged.")
    print("Review git diff before committing.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
